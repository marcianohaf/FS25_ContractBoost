-- MissionBalance
-- author: GMNGJoy
-- version: 1.0.0.0

MissionBalance = {}
MissionBalance.debug = true
MissionBalance.factor = 1.5
MissionBalance.customRewards = {
    baleMission = 3500, -- 2200
    baleWrapMission = 500, -- 300
    plowMission = 5000, -- 2800
    -- cultivateMission = 5000, -- 2300 
    -- sowMission = 5000, -- 2000
    -- harvestMission = 5000, -- 2500
    -- hoeMission = 5000, -- 1500
    -- weedMission = 5000, -- 2000
    -- herbicideMission = 5000, -- 1500
    -- fertilizeMission = 5000, -- 1500
    -- mowMission = 5000, -- 2500
    -- tedderMission = 5000, -- 1500
    -- stonePickMission = 5000, -- 2200
    -- deadwoodMission = 5000, -- 150
    -- treeTransportMission = 5000, -- 550
    -- destructibleRockMission = 5000, -- 550
}

MissionBalance.MAX_MISSIONS = 50
MissionBalance.MAX_MISSIONS_PER_FARM = 10
MissionBalance.MAX_MISSIONS_PER_TYPE = 5


function MissionBalance:init()
    if MissionBalance.debug then print('-- MissionBalance :: init.') end

    g_missionManager.loadMapData = Utils.appendedFunction(MissionManager.loadMapData, MissionBalance.loadMapData)

    print('-- ContractBoost:MissionBalance :: loaded.')
end

function MissionBalance:loadMapData()
    if MissionBalance.debug then print('-- MissionBalance :: loadMapData') end

    MissionBalance:initMissionSettings()
    MissionBalance:scaleMissionReward()

    if MissionBalance.debug then print('-- MissionBalance :: loadMapData complete') end
end

function MissionBalance:initMissionSettings()
    MissionManager.MAX_MISSIONS = MissionBalance.MAX_MISSIONS
    MissionManager.MAX_MISSIONS_PER_FARM = MissionBalance.MAX_MISSIONS_PER_FARM
    MissionManager.MISSION_GENERATION_INTERVAL = 360000 --360000
    if MissionBalance.debug then print('-- MissionBalance :: settings updated.') end
end

function MissionBalance:scaleMissionReward()
    if MissionBalance.debug then print('-- MissionBalance :: scaleMissionReward') end
    for _, missionType in ipairs(g_missionManager.missionTypes) do
        
        local typeName = missionType.name
        local prevValue = nil
        local newValue = nil

        if typeName == "baleWrapMission" then
            prevValue = missionType.data.rewardPerBale
            newValue = MissionBalance.customRewards[typeName] or missionType.data.rewardPerBale * MissionBalance.factor
            missionType.data.rewardPerBale = newValue
        elseif typeName == "deadwoodMission" or typeName == "treeTransportMission" then
            prevValue = missionType.data.rewardPerTree
            newValue = MissionBalance.customRewards[typeName] or missionType.data.rewardPerTree * MissionBalance.factor
            missionType.data.rewardPerTree = newValue
        elseif typeName == "destructibleRockMission" then
            prevValue = missionType.data.rewardPerRock
            newValue = MissionBalance.customRewards[typeName] or missionType.data.rewardPerRock * MissionBalance.factor
            missionType.data.rewardPerRock = newValue
        else
            prevValue = missionType.data.rewardPerHa
            newValue = MissionBalance.customRewards[typeName] or missionType.data.rewardPerHa * MissionBalance.factor
            missionType.data.rewardPerHa = newValue
        end

        -- update the number of each type to 5
        missionType.data.maxNumInstances = MissionBalance.MAX_MISSIONS_PER_TYPE

        if MissionBalance.debug then printf('---- Mission %s: %s | updated %s => %s', missionType.typeId, missionType.name, prevValue, newValue) end
    end

    if MissionBalance.debug then print('-- MissionBalance :: scaleMissionReward complete') end
end

MissionBalance:init();