-- MissionVehicles
-- author: GMNGJoy
-- version: 1.0.0

MissionVehicles = {}
MissionVehicles.debug = false
MissionVehicles.modDirectory = g_currentModDirectory

function MissionVehicles:init()
    if MissionVehicles.debug then print('-- MissionVehicles :: init.') end
    MissionManager.loadMissionVehicles = Utils.overwrittenFunction(MissionManager.loadMissionVehicles, MissionVehicles.load)
    print('-- MissionVehicles :: loaded.')
end

function MissionVehicles.load(superSelf, superFunc, path)
    local path2 = Utils.getFilename("xml/missionVehicles.xml", MissionVehicles.modDirectory)
    if path2 ~= nil then
        return superFunc(superSelf, path2)
    end
end

MissionVehicles:init();